# my-tiny-mvc-project 

### [MVC project assigned by xSpeedStudio](https://docs.google.com/document/d/1izjavOre__gkfGRqc55u-m9X_O7r6V4TpSuYoOAq0lA/edit?usp=sharing)

---

### Description :
If you are using Docker , then simply `cd docker` and run `docker-composer up -d` in the terminat thast all. The project is up and running. Just visit your localhost.

Or, if you are using other process (like xampp or wamp) just simply place the project to the public directory **Set your database credential in the config.php file** thats all. 
 
