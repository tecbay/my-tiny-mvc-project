<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>xSpeed</title>
    <style>
        /*.hash_key{*/
        /*    max-width: 13px;*/
        /*    overflow-y: hidden;*/
        /*    overflow-x: scroll;*/
        /*}*/
    </style>
    <link rel="stylesheet" href="/bootstrap/css/bootstrap.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">xSpeedStudio</a>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav nav-r">
            <li class="nav-item active">
                <a class="nav-link" href="/">Home <span class="sr-only"></span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/contact-us">Contact Us</a>
            </li>
        </ul>
    </div>
</nav>