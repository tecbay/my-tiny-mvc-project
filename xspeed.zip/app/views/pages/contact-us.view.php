<?php insert( 'layout.header' ) ?>
<div id="app">

</div>
<?php insert( 'layout.footer' ) ?>
