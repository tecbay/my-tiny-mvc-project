<?php


class Order extends Model {
	protected $table = 'orders';
}