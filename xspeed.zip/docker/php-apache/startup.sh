#!/bin/bash
supervisord
cron